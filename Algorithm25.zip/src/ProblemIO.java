
public interface ProblemIO {
	public String problemHeader();

	public String problemInput();

	public String problemOutput();
}
